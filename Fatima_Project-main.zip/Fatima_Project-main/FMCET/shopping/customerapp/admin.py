from django.contrib import admin
from customerapp.models import *
# Register your models here.
class product_model_list(admin.ModelAdmin):
	list_display=[field.name for field in product_model._meta.get_fields()]

class Register_model_list(admin.ModelAdmin):
	list_display=[field.name for field in Register_model._meta.get_fields()]

class Cart_model_list(admin.ModelAdmin):
	list_display=[field.name for field in Cart_model._meta.get_fields()]

admin.site.register(Register_model,Register_model_list)
admin.site.register(product_model,product_model_list)
admin.site.register(Cart_model,Cart_model_list)
