from django.shortcuts import render
from customerapp.forms import *
from customerapp.models import *
# Create your views here.
def Index(request):
    return render(request,"Home/Index.html")
def Login(request):
    return render(request,"Home/Login.html")
def Registration(request):
    Form=Register_form(request.POST)
    if Form.is_valid():
        Form.save()
    return render(request,"Home/Registration.html",{"form":Form})
def about(request):
    return render(request,"Home/about.html")
def log(request):
    name=request.GET["uname"]
    pws=request.GET["password"]
    choice=request.GET["choice"]
    if choice=="Admin" and name=="Admin" and pws=="1234":
        return render(request,"Admin/AdminHome.html")
    else:
        data=Register_model.objects.all().filter(id=name,password=pws)
        if data:
            request.session["id"]=name
            return render(request,"Customer/Cust_Home.html")  
        else:
            
            return render(request,"Home/Login.html")  

    return render(request,"Home/Login.html")
def addProduct(request):
    form=Product_form(request.POST,request.FILES or None)
    if form.is_valid():
        form.save()
    return render(request,"Admin/AddProduct.html",{"form":form})
def viewProduct(request):
    data=product_model.objects.all()
    return render(request,"Admin/ViewProduct.html",{"data":data})
def Cust_view_Product(request):
    data=product_model.objects.all()
    return render(request,"Customer/Cust_view_Product.html",{"data":data})
def buy(request):
    #Product ID
    pid=request.GET["id"]
    #User ID
    uid=request.session["id"]
    c=Cart_model()
    c.uid=uid
    c.pid=pid
    c.save()
    return Cust_view_Product(request)
