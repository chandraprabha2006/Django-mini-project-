
from django.db import models	
# Create your models here.	
class product_model(models.Model):	
    id=models.AutoField(primary_key=True)	
    name=models.CharField(max_length=50)	
    price=models.IntegerField()	
    description=models.TextField()	
    image=models.FileField(upload_to="product/",null=True)	
    class Meta:	
        db_table='product_register'	
class Register_model(models.Model):	
    id=models.AutoField(primary_key=True)	
    name=models.CharField(max_length=50)	
    mail=models.CharField(max_length=50)
    mobile=models.CharField(max_length=10)
    password=models.CharField(max_length=50)
    class Meta:	
        db_table='user_register'
class Cart_model(models.Model):	
    id=models.AutoField(primary_key=True)	
    uid=models.CharField(max_length=50)	
    pid=models.CharField(max_length=50)
    date=models.DateField(auto_now=True)
    class Meta:	
        db_table='cart_register'