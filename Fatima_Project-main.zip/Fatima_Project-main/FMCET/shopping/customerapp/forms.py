from django import forms
from customerapp.models import *

class Product_form(forms.ModelForm):
    class Meta:
        model=product_model
        fields='__all__'
class Register_form(forms.ModelForm):
    class Meta:
        model=Register_model
        fields='__all__'